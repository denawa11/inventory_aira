<?php $__env->startSection('title', 'Barang Masuk'); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span class="fw-semibold" style="color:#4e3f9e"><i class="fas fa-sign-in-alt me-2"></i>Daftar Barang Masuk</span>
        <a href="<?php echo e(route('barang-masuk.create')); ?>" class="btn btn-sm text-white" style="background:#4e3f9e;border-radius:8px">
            <i class="fas fa-plus me-1"></i> Tambah
        </a>
    </div>
    <div class="card-body p-0">
        <table class="table table-striped mb-0" style="font-size:0.875rem">
            <thead class="table-light">
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th class="text-center">Jumlah</th>
                    <th>Keterangan</th>
                    <th>Admin</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $barangMasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->tanggal->format('d/m/Y')); ?></td>
                    <td>
                        <span class="badge" style="background:#d4edda;color:#155724;font-size:0.8rem;font-weight:600">
                            <?php echo e($item->barang->kode_barang); ?>

                        </span>
                    </td>
                    <td class="fw-semibold"><?php echo e($item->barang->name); ?></td>
                    <td class="text-center">
                        <span class="badge bg-success px-3 py-2" style="font-size:0.85rem">
                            +<?php echo e($item->jumlah); ?>

                        </span>
                    </td>
                    <td><?php echo e($item->keterangan ?? '-'); ?></td>
                    <td>
                        <?php if($item->user): ?>
                            <div class="d-flex align-items-center gap-2">
                                <div style="width:28px;height:28px;border-radius:50%;background:#27ae60;color:white;display:flex;align-items:center;justify-content:center;font-size:0.7rem;font-weight:700;flex-shrink:0">
                                    <?php echo e(strtoupper(substr($item->user->name, 0, 1))); ?>

                                </div>
                                <span style="font-size:0.85rem"><?php echo e($item->user->name); ?></span>
                            </div>
                        <?php else: ?>
                            <span class="text-muted" style="font-size:0.8rem">—</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <form action="<?php echo e(route('barang-masuk.destroy', $item)); ?>" method="POST" style="display:inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm" style="background:#c0392b;color:white;border:none;border-radius:6px" onclick="return confirm('Yakin hapus? Stok akan dikurangi.')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center py-4 text-muted">
                        <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                        Belum ada data barang masuk
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer bg-white"><?php echo e($barangMasuk->links()); ?></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\inventory-app\resources\views/barang-masuk/index.blade.php ENDPATH**/ ?>