
<?php $__env->startSection('title', 'Tambah Barang Keluar'); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header bg-white fw-semibold">Tambah Barang Keluar</div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><p class="mb-0"><?php echo e($error); ?></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('barang-keluar.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Barang</label>
                    <select name="barang_id" class="form-select">
                        <option value="">-- Pilih Barang --</option>
                        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($barang->id); ?>" <?php echo e(old('barang_id') == $barang->id ? 'selected' : ''); ?>>
                                <?php echo e($barang->kode_barang); ?> - <?php echo e($barang->name); ?> (Stock: <?php echo e($barang->stock); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Jumlah</label>
                    <input type="number" name="jumlah" class="form-control" value="<?php echo e(old('jumlah', 1)); ?>" min="1">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Tanggal</label>
                    <input type="date" name="tanggal" class="form-control" value="<?php echo e(old('tanggal', date('Y-m-d'))); ?>">
                </div>
                <div class="col-md-12">
                    <label class="form-label">Keterangan</label>
                    <textarea name="keterangan" class="form-control" rows="3"><?php echo e(old('keterangan')); ?></textarea>
                </div>
            </div>
            <div class="mt-3 d-flex gap-2">
                <button type="submit" class="btn text-white" style="background:#4e3f9e">Simpan</button>
                <a href="<?php echo e(route('barang-keluar.index')); ?>" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\inventory-app\resources\views/barang-keluar/create.blade.php ENDPATH**/ ?>