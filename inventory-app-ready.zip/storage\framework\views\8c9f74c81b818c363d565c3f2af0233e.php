
<?php $__env->startSection('title', 'Edit Barang'); ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header bg-white fw-semibold">Edit Barang</div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><p class="mb-0"><?php echo e($error); ?></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('barangs.update', $barang)); ?>">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Kode Barang</label>
                    <input type="text" name="kode_barang" class="form-control" value="<?php echo e(old('kode_barang', $barang->kode_barang)); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Nama Barang</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $barang->name)); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Colour Number</label>
                    <input type="text" name="colour_number" class="form-control" value="<?php echo e(old('colour_number', $barang->colour_number)); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Merk</label>
                    <input type="text" name="merk" class="form-control" value="<?php echo e(old('merk', $barang->merk)); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Colour</label>
                    <input type="text" name="colour" class="form-control" value="<?php echo e(old('colour', $barang->colour)); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Stock</label>
                    <input type="number" name="stock" class="form-control" value="<?php echo e(old('stock', $barang->stock)); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Stock Minimum</label>
                    <input type="number" name="stock_minimum" class="form-control" value="<?php echo e(old('stock_minimum', $barang->stock_minimum)); ?>">
                </div>
                <div class="col-md-12">
                    <div class="form-check">
                        <input type="checkbox" name="opened" value="1" class="form-check-input" <?php echo e($barang->opened ? 'checked' : ''); ?>>
                        <label class="form-check-label">Opened</label>
                    </div>
                </div>
                <div class="col-md-12">
                    <label class="form-label">Keterangan</label>
                    <textarea name="keterangan" class="form-control" rows="3"><?php echo e(old('keterangan', $barang->keterangan)); ?></textarea>
                </div>
            </div>
            <div class="mt-3 d-flex gap-2">
                <button type="submit" class="btn text-white" style="background:#4e3f9e">Update</button>
                <a href="<?php echo e(route('barangs.index')); ?>" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\inventory-app\resources\views/barangs/edit.blade.php ENDPATH**/ ?>