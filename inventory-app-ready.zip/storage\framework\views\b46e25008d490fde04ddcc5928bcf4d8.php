
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="stat-card" style="background:linear-gradient(135deg,#4e3f9e,#6c5ce7)">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div style="opacity:0.8;font-size:0.85rem">Data Barang</div>
                    <div style="font-size:2rem;font-weight:700"><?php echo e($totalBarang); ?></div>
                </div>
                <i class="fas fa-box fa-2x" style="opacity:0.5"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card" style="background:linear-gradient(135deg,#00b894,#00cec9)">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div style="opacity:0.8;font-size:0.85rem">Barang Masuk</div>
                    <div style="font-size:2rem;font-weight:700"><?php echo e($totalBarangMasuk); ?></div>
                </div>
                <i class="fas fa-sign-in-alt fa-2x" style="opacity:0.5"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card" style="background:linear-gradient(135deg,#e17055,#d63031)">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div style="opacity:0.8;font-size:0.85rem">Barang Keluar</div>
                    <div style="font-size:2rem;font-weight:700"><?php echo e($totalBarangKeluar); ?></div>
                </div>
                <i class="fas fa-sign-out-alt fa-2x" style="opacity:0.5"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card" style="background:linear-gradient(135deg,#fdcb6e,#e67e22)">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div style="opacity:0.8;font-size:0.85rem">Data User</div>
                    <div style="font-size:2rem;font-weight:700"><?php echo e($totalUser); ?></div>
                </div>
                <i class="fas fa-users fa-2x" style="opacity:0.5"></i>
            </div>
        </div>
    </div>
</div>

<?php if($stokMinimum->count() > 0): ?>
<div class="card">
    <div class="card-header bg-white fw-semibold">
        <i class="fas fa-info-circle text-warning me-2"></i>
        Stok barang telah mencapai batas minimum
    </div>
    <div class="card-body p-0">
        <table class="table table-striped mb-0">
            <thead class="table-light">
                <tr>
                    <th>No</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Stok</th>
                    <th>Stok Minimum</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $stokMinimum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->kode_barang); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><span class="badge bg-danger"><?php echo e($item->stock); ?></span></td>
                    <td><?php echo e($item->stock_minimum); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\inventory-app\resources\views/dashboard.blade.php ENDPATH**/ ?>